extends CanvasLayer
## Roda de armas (tecla Q / botão "Armas"): escolha a arma tocando ou clicando. Pausa o jogo
## enquanto aberta. Também dá para trocar com as teclas 1 a 9 ou a roda do mouse.

var combat: Node
var is_open := false

var _root: Control
var _holder: Control


func _ready() -> void:
    layer = 9
    process_mode = Node.PROCESS_MODE_ALWAYS
    visible = false
    _root = Control.new()
    add_child(_root)
    _root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var theme := Theme.new()
    theme.default_font_size = 20
    _root.theme = theme
    var dim := ColorRect.new()
    dim.color = Color(0.0, 0.0, 0.0, 0.6)
    _root.add_child(dim)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _holder = Control.new()
    _root.add_child(_holder)
    _holder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("weapon_wheel"):
        if is_open:
            close()
        elif combat != null and not get_tree().paused:
            open()
        get_viewport().set_input_as_handled()
    elif is_open and event.is_action_pressed("pause"):
        close()
        get_viewport().set_input_as_handled()


func open() -> void:
    _rebuild()
    visible = true
    is_open = true
    GameState.set_paused(true)


func close() -> void:
    visible = false
    is_open = false
    GameState.set_paused(false)


func _rebuild() -> void:
    for child in _holder.get_children():
        child.queue_free()
    var size := get_viewport().get_visible_rect().size
    var center := size * 0.5
    var count: int = combat.WEAPONS.size()
    var radius := minf(size.x, size.y) * 0.34
    var title := Label.new()
    title.text = "ARMAS"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.position = center - Vector2(100.0, 14.0)
    title.size = Vector2(200.0, 28.0)
    _holder.add_child(title)
    for i in count:
        var angle := -PI * 0.5 + TAU * float(i) / float(count)
        var button := Button.new()
        button.text = "%d. %s" % [i + 1, combat.label_for(i)]
        button.size = Vector2(230.0, 62.0)
        button.position = center + Vector2(cos(angle), sin(angle)) * radius - button.size * 0.5
        if i == combat.current:
            button.modulate = Color(1.0, 0.85, 0.3)
        button.pressed.connect(func() -> void:
            combat.select(i)
            close()
        )
        _holder.add_child(button)
