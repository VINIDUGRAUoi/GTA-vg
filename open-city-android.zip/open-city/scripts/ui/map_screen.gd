extends CanvasLayer
## Mapa em tela cheia (tecla M / botão "Mapa"). Toque ou clique no mapa para definir o
## destino do GPS; a rota aparece no mapa e no minimapa.

const MapViewScript := preload("res://scripts/ui/map_view.gd")

var is_open := false
var player: Node3D

var _view: Control


func _ready() -> void:
    layer = 8
    process_mode = Node.PROCESS_MODE_ALWAYS
    visible = false

    var root := Control.new()
    add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var theme := Theme.new()
    theme.default_font_size = 22
    root.theme = theme

    var bg := ColorRect.new()
    bg.color = Color(0.0, 0.0, 0.0, 0.85)
    root.add_child(bg)
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    _view = MapViewScript.new()
    _view.mini = false
    root.add_child(_view)
    _view.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _view.offset_top = 70.0
    _view.offset_left = 10.0
    _view.offset_right = -10.0
    _view.offset_bottom = -10.0
    _view.waypoint_picked.connect(_on_waypoint_picked)

    var bar := HBoxContainer.new()
    root.add_child(bar)
    bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    bar.offset_left = 10.0
    bar.offset_right = -10.0
    bar.offset_top = 8.0
    bar.offset_bottom = 62.0

    var title := Label.new()
    title.text = "Mapa — toque para definir o destino (GPS)"
    title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    bar.add_child(title)

    var clear := Button.new()
    clear.text = "Limpar destino"
    clear.pressed.connect(func() -> void: GameState.clear_waypoint())
    bar.add_child(clear)

    var close_button := Button.new()
    close_button.text = "Fechar"
    close_button.pressed.connect(close)
    bar.add_child(close_button)


func bind(world_data: Dictionary, p: Node3D) -> void:
    player = p
    _view.setup(world_data, p)


func open() -> void:
    visible = true
    is_open = true
    GameState.set_paused(true)


func close() -> void:
    visible = false
    is_open = false
    GameState.set_paused(false)


func _on_waypoint_picked(pos: Vector2) -> void:
    GameState.set_waypoint(pos)
    if player != null:
        GameState.update_route(Vector2(player.global_position.x, player.global_position.z))
