extends Control
## Desenha o mapa da cidade (ruas, prédios, parques, veículos, jogador, destino e rota do GPS).
## mini = true: minimapa que acompanha o jogador. mini = false: mapa completo clicável.

signal waypoint_picked(pos: Vector2)

const GraphScript := preload("res://scripts/ai/city_graph.gd")

var mini := true
var world: Dictionary = {}
var player: Node3D
var zoom_m := 200.0 # largura visível do minimapa, em metros


func setup(world_data: Dictionary, p: Node3D) -> void:
    world = world_data
    player = p
    clip_contents = true
    mouse_filter = Control.MOUSE_FILTER_IGNORE if mini else Control.MOUSE_FILTER_STOP
    queue_redraw()


func _process(_delta: float) -> void:
    if is_visible_in_tree():
        queue_redraw()


func _player_xz() -> Vector2:
    if player == null or not is_instance_valid(player):
        return Vector2.ZERO
    return Vector2(player.global_position.x, player.global_position.z)


func _scale() -> float:
    if mini:
        return size.x / zoom_m
    return minf(size.x, size.y) / (GraphScript.city_half_extent() * 2.0 + 20.0)


func _center_world() -> Vector2:
    return _player_xz() if mini else Vector2.ZERO


func _w2s(p: Vector2) -> Vector2:
    return size * 0.5 + (p - _center_world()) * _scale()


func _s2w(s: Vector2) -> Vector2:
    return _center_world() + (s - size * 0.5) / _scale()


func _gui_input(event: InputEvent) -> void:
    if mini:
        return
    var mb := event as InputEventMouseButton
    if mb != null and mb.pressed and mb.button_index == MOUSE_BUTTON_LEFT:
        var half := GraphScript.city_half_extent()
        var wp := _s2w(mb.position)
        waypoint_picked.emit(Vector2(clampf(wp.x, -half, half), clampf(wp.y, -half, half)))
        accept_event()


func _draw() -> void:
    if world.is_empty():
        return
    var sc := _scale()
    var half := GraphScript.city_half_extent()
    draw_rect(Rect2(Vector2.ZERO, size), Color(0.18, 0.3, 0.18))

    var road_color := Color(0.25, 0.25, 0.28)
    var road_px := maxf(2.0, GraphScript.ROAD_WIDTH * sc)
    for k in range(GraphScript.ROAD_MIN, GraphScript.ROAD_MAX + 1):
        var c := float(k) * GraphScript.PITCH
        draw_line(_w2s(Vector2(c, -half)), _w2s(Vector2(c, half)), road_color, road_px)
        draw_line(_w2s(Vector2(-half, c)), _w2s(Vector2(half, c)), road_color, road_px)

    var view := Rect2(_s2w(Vector2.ZERO), size / sc)
    for item in world.get("parks", []):
        var park: Rect2 = item
        if view.intersects(park):
            draw_rect(Rect2(_w2s(park.position), park.size * sc), Color(0.25, 0.55, 0.25))
    for item in world.get("buildings", []):
        var b: Rect2 = item
        if view.intersects(b):
            draw_rect(Rect2(_w2s(b.position), b.size * sc), Color(0.55, 0.55, 0.6))

    var dot := 3.0 if mini else 5.0
    for v in get_tree().get_nodes_in_group("vehicles"):
        var vp := _w2s(Vector2(v.global_position.x, v.global_position.z))
        draw_rect(Rect2(vp - Vector2(dot, dot), Vector2(dot, dot) * 2.0), Color(1.0, 0.7, 0.1))

    var gs := get_node_or_null("/root/GameState")
    if gs != null and gs.has_waypoint:
        var pts: PackedVector2Array = gs.route.duplicate()
        if pts.size() >= 2:
            pts[0] = _player_xz()
            for i in pts.size() - 1:
                draw_line(_w2s(pts[i]), _w2s(pts[i + 1]), Color(0.2, 0.9, 1.0), 3.0)
        var wp := _w2s(gs.waypoint)
        draw_circle(wp, dot * 1.6, Color(1.0, 0.15, 0.15))
        draw_arc(wp, dot * 2.4, 0.0, TAU, 20, Color(1, 1, 1), 2.0)

    if player != null and is_instance_valid(player):
        var pp := _w2s(_player_xz())
        var f: Vector2 = player.get_forward_xz()
        var perp := Vector2(-f.y, f.x)
        var s := 10.0 if mini else 14.0
        draw_colored_polygon(PackedVector2Array([pp + f * s, pp - f * s * 0.6 + perp * s * 0.6, pp - f * s * 0.6 - perp * s * 0.6]), Color(1, 1, 1))
    draw_rect(Rect2(Vector2.ZERO, size), Color(1, 1, 1, 0.6), false, 2.0)
