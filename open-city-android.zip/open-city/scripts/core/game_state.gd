extends Node
## Autoload "GameState": estado compartilhado (destino do GPS e pausa).

const GraphScript := preload("res://scripts/ai/city_graph.gd")

signal waypoint_changed

var has_waypoint := false
var waypoint := Vector2.ZERO # x, z no mundo
var route := PackedVector2Array()


func set_waypoint(position_xz: Vector2) -> void:
    has_waypoint = true
    waypoint = position_xz
    route = PackedVector2Array()
    waypoint_changed.emit()


func clear_waypoint() -> void:
    has_waypoint = false
    route = PackedVector2Array()
    waypoint_changed.emit()


func update_route(from_xz: Vector2) -> void:
    if has_waypoint:
        route = GraphScript.route(from_xz, waypoint)


func set_paused(value: bool) -> void:
    get_tree().paused = value
    if not OS.has_feature("mobile"):
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if value else Input.MOUSE_MODE_CAPTURED
