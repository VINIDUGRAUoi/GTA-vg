extends RefCounted
## Efeitos sonoros sintetizados em código (sem arquivos de áudio): tiros, golpes, explosões.

const MIX := 22050.0


## Rajada de ruído com decaimento + um "baque" grave. thump_hz baixo = som mais pesado.
static func play_noise(parent: Node, duration: float, volume_db: float, thump_hz: float) -> void:
    if parent == null or not parent.is_inside_tree():
        return
    var gen := AudioStreamGenerator.new()
    gen.mix_rate = MIX
    gen.buffer_length = duration + 0.1
    var player := AudioStreamPlayer.new()
    player.stream = gen
    player.volume_db = volume_db
    parent.add_child(player)
    player.play()
    var playback := player.get_stream_playback() as AudioStreamGeneratorPlayback
    if playback != null:
        var n := int(duration * MIX)
        var buffer := PackedVector2Array()
        buffer.resize(n)
        var low := 0.0
        for i in n:
            var t := float(i) / float(n)
            var env := pow(1.0 - t, 2.5)
            low += ((randf() * 2.0 - 1.0) - low) * 0.35
            var s := (low * 0.8 + sin(float(i) / MIX * TAU * thump_hz) * 0.5) * env
            buffer[i] = Vector2(s, s)
        playback.push_buffer(buffer)
    parent.get_tree().create_timer(duration + 0.3).timeout.connect(player.queue_free)
