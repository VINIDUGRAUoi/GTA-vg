extends Node3D
## Ponto de entrada. Monta mundo, HUD, jogador, veículos estacionados, NPCs, mapa e menus.
## A ordem importa: o HUD é conectado antes do jogador emitir o estado inicial.

const WorldBuilder := preload("res://scripts/world/world_builder.gd")
const PlayerScript := preload("res://scripts/player/player.gd")
const HudScript := preload("res://scripts/ui/hud.gd")
const TouchScript := preload("res://scripts/ui/touch_controls.gd")
const MapScreenScript := preload("res://scripts/ui/map_screen.gd")
const PauseScript := preload("res://scripts/ui/pause_menu.gd")
const WheelScript := preload("res://scripts/ui/weapon_wheel.gd")
const NpcManagerScript := preload("res://scripts/ai/npc_manager.gd")
const FactoryScript := preload("res://scripts/vehicles/vehicle_factory.gd")

const SPAWN_POSITION := Vector3(0.0, 0.1, 0.0)

## [tipo, posição, rotação Y em graus]. Rotação -90 = frente para +X, 90 = frente para -X, 0 = frente para -Z.
const PARKED := [
    ["sport", Vector3(14.0, 1.3, 4.5), -90.0],
    ["sedan", Vector3(26.0, 1.3, 4.5), -90.0],
    ["suv", Vector3(-14.0, 1.3, -4.5), 90.0],
    ["pickup", Vector3(-27.0, 1.3, -4.5), 90.0],
    ["truck", Vector3(42.0, 1.3, -4.5), 90.0],
    ["van", Vector3(-40.0, 1.3, 4.5), -90.0],
    ["sedan", Vector3(56.5, 1.3, -30.0), 0.0],
    ["sport", Vector3(-56.5, 1.3, 30.0), 180.0],
]

var _beacon: MeshInstance3D
var _status: Label
var _boot_camera: Camera3D


## Monta o jogo em etapas (uma por quadro), mostrando o progresso na tela. Se algo travar ou
## falhar, o último texto fica visível, e uma câmera reserva evita a tela toda cinza.
func _ready() -> void:
    _make_status_label()
    _boot_camera = Camera3D.new()
    _boot_camera.position = Vector3(0.0, 8.0, 14.0)
    _boot_camera.rotation_degrees = Vector3(-20.0, 0.0, 0.0)
    add_child(_boot_camera)
    _boot_camera.make_current()
    var mobile := OS.has_feature("mobile")

    await _step("Criando o mundo...")
    var world := WorldBuilder.new()
    world.name = "World"
    add_child(world)
    world.build(false)
    var map_data: Dictionary = world.get_map_data()

    var remaining := 1
    while remaining > 0:
        remaining = world.stream_step(Vector2.ZERO, 2, 3)
        await _step("Montando a cidade... (faltam %d)" % remaining)

    await _step("Estacionando os carros...")
    for entry in PARKED:
        var vehicle = FactoryScript.create(entry[0])
        vehicle.position = entry[1]
        vehicle.rotation_degrees.y = entry[2] + 180.0 # frente do veículo dirigível = +Z
        add_child(vehicle)

    await _step("Criando a interface...")
    var hud := HudScript.new()
    hud.name = "Hud"
    hud.touch_mode = mobile
    add_child(hud)

    await _step("Criando o personagem...")
    var player := PlayerScript.new()
    player.name = "Player"
    player.spawn_position = SPAWN_POSITION
    player.health_changed.connect(hud.set_health)
    player.stamina_changed.connect(hud.set_stamina)
    player.driving_changed.connect(hud.on_driving_changed)
    player.speed_changed.connect(hud.on_speed_changed)
    player.prompt_changed.connect(hud.on_prompt_changed)
    player.weapon_info.connect(hud.on_weapon_info)
    add_child(player)
    player.global_position = SPAWN_POSITION
    hud.bind(player, map_data)
    world.focus = player
    _boot_camera.queue_free()

    await _step("Criando pedestres e trânsito...")
    var npcs := NpcManagerScript.new()
    npcs.name = "NpcManager"
    npcs.player = player
    add_child(npcs)

    await _step("Criando menus e mapa...")
    var map_screen := MapScreenScript.new()
    map_screen.name = "MapScreen"
    add_child(map_screen)
    map_screen.bind(map_data, player)

    var pause_menu := PauseScript.new()
    pause_menu.name = "PauseMenu"
    pause_menu.player = player
    pause_menu.map_screen = map_screen
    if player.combat != null:
        var wheel := WheelScript.new()
        wheel.name = "WeaponWheel"
        wheel.combat = player.combat
        add_child(wheel)
        pause_menu.wheel = wheel
    add_child(pause_menu)

    if mobile:
        await _step("Ligando os controles de toque...")
        var layer := CanvasLayer.new()
        layer.name = "TouchLayer"
        add_child(layer)
        var touch := TouchScript.new()
        layer.add_child(touch)
        touch.look_dragged.connect(player.apply_look)
        touch.move_changed.connect(player.set_touch_move)
        touch.move_changed.connect(hud.on_stick_changed)
        player.driving_changed.connect(func(driving: bool, _vehicle_name: String) -> void: touch.set_driving(driving))

    _build_beacon()
    GameState.waypoint_changed.connect(_on_waypoint_changed)
    _status.visible = false
    _build_diagnostics(player, world)


func _make_status_label() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 100
    add_child(layer)
    _status = Label.new()
    _status.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _status.add_theme_font_size_override("font_size", 28)
    _status.add_theme_color_override("font_outline_color", Color.BLACK)
    _status.add_theme_constant_override("outline_size", 8)
    layer.add_child(_status)
    _status.anchor_left = 0.5
    _status.anchor_right = 0.5
    _status.anchor_top = 0.4
    _status.anchor_bottom = 0.4
    _status.offset_left = -450.0
    _status.offset_right = 450.0
    _status.offset_top = -60.0
    _status.offset_bottom = 60.0
    _status.text = "Iniciando..."


## Mostra o texto do passo atual e espera um quadro para ele aparecer na tela.
func _step(text: String) -> void:
    _status.text = text + "\n(se ficar parado aqui, me diga este texto)"
    print(text)
    await get_tree().process_frame


func _build_beacon() -> void:
    _beacon = MeshInstance3D.new()
    var cyl := CylinderMesh.new()
    cyl.top_radius = 0.5
    cyl.bottom_radius = 0.5
    cyl.height = 80.0
    _beacon.mesh = cyl
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(1.0, 0.1, 0.1, 0.35)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    _beacon.material_override = mat
    _beacon.visible = false
    add_child(_beacon)


func _on_waypoint_changed() -> void:
    _beacon.visible = GameState.has_waypoint
    if GameState.has_waypoint:
        _beacon.position = Vector3(GameState.waypoint.x, 40.0, GameState.waypoint.y)


# ------------------------------------------------------------------ diagnóstico
## Lista de scripts do jogo (para detectar os que não compilam).
const ALL_SCRIPTS := [
    "res://scripts/ai/city_graph.gd",
    "res://scripts/ai/humanoid.gd",
    "res://scripts/ai/npc_manager.gd",
    "res://scripts/ai/pedestrian.gd",
    "res://scripts/ai/traffic_car.gd",
    "res://scripts/combat/combat.gd",
    "res://scripts/combat/explosion.gd",
    "res://scripts/combat/grenade.gd",
    "res://scripts/core/game_settings.gd",
    "res://scripts/core/game_state.gd",
    "res://scripts/core/geo.gd",
    "res://scripts/core/input_setup.gd",
    "res://scripts/core/sfx.gd",
    "res://scripts/main.gd",
    "res://scripts/player/player.gd",
    "res://scripts/save/save_game.gd",
    "res://scripts/ui/hud.gd",
    "res://scripts/ui/map_screen.gd",
    "res://scripts/ui/map_view.gd",
    "res://scripts/ui/pause_menu.gd",
    "res://scripts/ui/touch_controls.gd",
    "res://scripts/ui/weapon_wheel.gd",
    "res://scripts/vehicles/vehicle.gd",
    "res://scripts/vehicles/vehicle_builder.gd",
    "res://scripts/vehicles/vehicle_data.gd",
    "res://scripts/vehicles/vehicle_factory.gd",
    "res://scripts/world/textures.gd",
    "res://scripts/world/world_builder.gd"
]


## Mostra por alguns segundos o estado dos sistemas principais (ajuda a achar o que falhou).
func _build_diagnostics(player: Node3D, world: Node3D) -> void:
    var layer := CanvasLayer.new()
    layer.layer = 50
    add_child(layer)
    var label := Label.new()
    label.position = Vector2(330.0, 10.0)
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    label.add_theme_color_override("font_color", Color(1.0, 1.0, 0.4))
    label.add_theme_color_override("font_outline_color", Color.BLACK)
    label.add_theme_constant_override("outline_size", 6)
    layer.add_child(label)
    get_tree().create_timer(2.0).timeout.connect(func() -> void:
        label.text = _diagnose(player, world)
        print(label.text)
        get_tree().create_timer(40.0).timeout.connect(func() -> void: label.visible = false)
    )


func _diagnose(player: Node3D, world: Node3D) -> String:
    var lines: Array[String] = ["DIAGNÓSTICO (some em 40 s)"]
    var bad: Array[String] = []
    for path: String in ALL_SCRIPTS:
        var script := load(path) as Script
        if script == null or not script.can_instantiate():
            bad.append(path.get_file())
    lines.append("Scripts com erro: " + (", ".join(bad) if not bad.is_empty() else "nenhum"))
    lines.append("Pessoa (esqueleto): " + ("ok" if player.get_rig().has("skeleton") else "FALHOU"))
    lines.append("Combate: " + ("ok" if player.combat != null and player.combat.ready_ok else "FALHOU"))
    lines.append("Mundo: %d células carregadas" % world.get("_loaded").size())
    lines.append("Jogador: y=%.2f no chão=%s" % [player.global_position.y, str(player.is_on_floor())])
    lines.append("Ação move_forward: " + ("ok" if InputMap.has_action("move_forward") else "FALTA"))
    for warning in player.warnings:
        lines.append("Aviso: " + warning)
    return "\n".join(lines)
