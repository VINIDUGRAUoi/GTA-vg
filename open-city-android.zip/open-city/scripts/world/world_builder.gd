extends Node3D
## Gera a cidade: mundo de 20x20 quarteirões (~1 km de lado) com centro de prédios altos e
## lojas, bairro de prédios médios, subúrbio de casas, zona industrial com galpões e
## contêineres, praças com árvores, avenidas com faixas e postes, praia e mar nas bordas.
## O mapa inteiro é PLANEJADO no início (layouts baratos, usados no mapa), mas a geometria
## de cada célula só é construída perto do jogador e descartada quando ele se afasta
## (carregamento progressivo). Tudo é procedural; a geração é determinística (SEED fixa).

const GeoScript := preload("res://scripts/core/geo.gd")
const TexScript := preload("res://scripts/world/textures.gd")
const GraphScript := preload("res://scripts/ai/city_graph.gd")

const BLOCK_SIZE := GraphScript.BLOCK_SIZE
const ROAD_WIDTH := GraphScript.ROAD_WIDTH
const PITCH := GraphScript.PITCH
const GRID_MIN := GraphScript.BLOCK_MIN
const GRID_MAX := GraphScript.BLOCK_MAX
const SEED := 1337
const PARK_CHANCE := 0.12

const FLOOR_H := 3.5
const GROUND_FLOOR_H := 4.0
const FACADE_TILE := Vector2(8.0, 7.0)
const GROUND_TOP := 0.06 # topo da colisão do chão
const GRASS_Y := 0.05
const FLAT_Y := 0.06 # ruas e calçadas
const MARK_Y := 0.085 # faixas pintadas

const MATS := ["facade_glass", "facade_brick", "facade_concrete", "storefront", "house_wall",
    "roof_gravel", "roof_tile", "concrete", "grass", "asphalt", "plain"]
const AWNINGS := [Color(0.8, 0.2, 0.2), Color(0.2, 0.5, 0.3), Color(0.2, 0.3, 0.6), Color(0.9, 0.7, 0.2)]
const PLASTERS := [Color(1.0, 1.0, 0.95), Color(0.98, 0.9, 0.75), Color(0.85, 0.92, 0.98), Color(0.98, 0.85, 0.8), Color(0.9, 0.96, 0.88)]
const ROOFS := [Color(0.75, 0.32, 0.22), Color(0.32, 0.34, 0.4), Color(0.45, 0.3, 0.22)]
const WAREHOUSES := [Color(0.55, 0.62, 0.7), Color(0.85, 0.85, 0.82), Color(0.7, 0.62, 0.5)]
const CONTAINERS := [Color(0.75, 0.2, 0.15), Color(0.15, 0.35, 0.6), Color(0.2, 0.5, 0.3), Color(0.85, 0.6, 0.15), Color(0.5, 0.5, 0.52)]

var building_count := 0
var park_count := 0
var building_rects: Array[Rect2] = []
var park_rects: Array[Rect2] = []
## Jogador (ou câmera): o mundo é carregado/descarregado ao redor dele.
var focus: Node3D

var _sun: DirectionalLight3D
var _materials := {}
var _layouts := {} # Vector2i -> Dictionary
var _loaded := {} # Vector2i -> Node3D
var _stream_timer := 0.0


func build(stream_now: bool = true) -> void:
    building_count = 0
    park_count = 0
    building_rects.clear()
    park_rects.clear()
    _layouts.clear()
    _loaded.clear()
    _add_environment()
    _add_ground()
    for i in range(GRID_MIN, GRID_MAX + 2):
        for j in range(GRID_MIN, GRID_MAX + 2):
            _layouts[Vector2i(i, j)] = _make_layout(i, j)
    _add_test_props()
    if stream_now:
        _stream(Vector2.ZERO, 2, 100000)


## Carrega até `budget` células por chamada. Devolve quantas ainda faltam.
func stream_step(center: Vector2, radius: int, budget: int) -> int:
    return _stream(center, radius, budget)


func _process(delta: float) -> void:
    _stream_timer -= delta
    if _stream_timer > 0.0 or focus == null or not is_instance_valid(focus):
        return
    _stream_timer = 0.3
    _stream(Vector2(focus.global_position.x, focus.global_position.z), _radius_cells(), 2)


func _radius_cells() -> int:
    var gs := get_node_or_null("/root/GameSettings")
    var vd := 250.0
    if gs != null:
        vd = gs.view_distance
    return clampi(ceili((vd + 60.0) / PITCH), 3, 8)


func _cell_center(key: Vector2i) -> Vector2:
    return Vector2((float(key.x) + 0.5) * PITCH, (float(key.y) + 0.5) * PITCH)


## Carrega as células perto de `center` (as mais próximas primeiro) e descarta as distantes.
func _stream(center: Vector2, radius: int, budget: int) -> int:
    var ci := floori(center.x / PITCH)
    var cj := floori(center.y / PITCH)
    var missing: Array = []
    for i in range(ci - radius - 1, ci + radius + 2):
        for j in range(cj - radius - 1, cj + radius + 2):
            var key := Vector2i(i, j)
            if not _layouts.has(key) or _loaded.has(key):
                continue
            if _cell_center(key).distance_to(center) <= (float(radius) + 0.5) * PITCH:
                missing.append(key)
    for key in _loaded.keys():
        if _cell_center(key).distance_to(center) > (float(radius) + 1.5) * PITCH:
            _loaded[key].queue_free()
            _loaded.erase(key)
    missing.sort_custom(func(a: Vector2i, b: Vector2i) -> bool: return _cell_center(a).distance_to(center) < _cell_center(b).distance_to(center))
    var built := 0
    for key: Vector2i in missing:
        if budget <= 0:
            break
        _build_cell(key.x, key.y)
        budget -= 1
        built += 1
    return maxi(missing.size() - built, 0)


# ------------------------------------------------------------------ ambiente

func _add_environment() -> void:
    var sky_material := ProceduralSkyMaterial.new()
    var sky := Sky.new()
    sky.sky_material = sky_material
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    var world_env := WorldEnvironment.new()
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50.0, -30.0, 0.0)
    sun.shadow_enabled = _shadows_enabled()
    sun.directional_shadow_max_distance = 120.0
    add_child(sun)
    _sun = sun
    var gs := get_node_or_null("/root/GameSettings")
    if gs != null:
        gs.changed.connect(_on_settings_changed)


func _shadows_enabled() -> bool:
    var gs := get_node_or_null("/root/GameSettings")
    if gs != null:
        return gs.shadows
    return not OS.has_feature("mobile") # sombras pesam em celular


func _on_settings_changed() -> void:
    if _sun != null:
        _sun.shadow_enabled = _shadows_enabled()


## Dados para o mapa: retângulos (x, z, largura, profundidade) de prédios e parques.
func get_map_data() -> Dictionary:
    return {"buildings": building_rects, "parks": park_rects}


# --------------------------------------------------------------------- malhas

func _new_sts() -> Dictionary:
    var d := {}
    for m in MATS:
        d[m] = GeoScript.new_st()
    return d


func _commit(sts: Dictionary, parent: Node3D, node_name: String) -> void:
    var mesh := ArrayMesh.new()
    for key: String in sts:
        var st: SurfaceTool = sts[key]
        if not GeoScript.has_data(st):
            continue
        st.commit(mesh)
        mesh.surface_set_material(mesh.get_surface_count() - 1, TexScript.material(key))
    if mesh.get_surface_count() == 0:
        return
    var mi := MeshInstance3D.new()
    mi.name = node_name
    mi.mesh = mesh
    parent.add_child(mi)


func _collider(body: StaticBody3D, pos: Vector3, size: Vector3) -> void:
    var shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = size
    shape.shape = box
    shape.position = pos
    body.add_child(shape)


func _add_ground() -> void:
    var grass_half := GraphScript.city_half_extent() + 2.0 * PITCH
    var sand_half := grass_half + 100.0
    var body := StaticBody3D.new()
    body.name = "GroundBody"
    _collider(body, Vector3(0.0, GROUND_TOP - 0.5, 0.0), Vector3(sand_half * 2.0, 1.0, sand_half * 2.0))
    add_child(body)
    var sts := _new_sts()
    GeoScript.flat_quad(sts["grass"], -grass_half, -grass_half, grass_half, grass_half, GRASS_Y, 6.0, Color.WHITE)
    var sand := Color(0.88, 0.8, 0.58)
    var plain: SurfaceTool = sts["plain"]
    GeoScript.flat_quad(plain, -sand_half, -sand_half, sand_half, -grass_half, GRASS_Y, 6.0, sand)
    GeoScript.flat_quad(plain, -sand_half, grass_half, sand_half, sand_half, GRASS_Y, 6.0, sand)
    GeoScript.flat_quad(plain, -sand_half, -grass_half, -grass_half, grass_half, GRASS_Y, 6.0, sand)
    GeoScript.flat_quad(plain, grass_half, -grass_half, sand_half, grass_half, GRASS_Y, 6.0, sand)
    GeoScript.flat_quad(plain, -4000.0, -4000.0, 4000.0, 4000.0, -0.6, 6.0, Color(0.1, 0.35, 0.55)) # mar
    _commit(sts, self, "GroundMesh")


# ------------------------------------------------------------------ planejamento

func _snap4(v: float) -> float:
    return maxf(8.0, roundf(v / 4.0) * 4.0)


func _register(e: Dictionary) -> void:
    building_count += 1
    var pos: Vector3 = e["pos"]
    building_rects.append(Rect2(pos.x - float(e["w"]) * 0.5, pos.z - float(e["d"]) * 0.5, float(e["w"]), float(e["d"])))


func _make_layout(i: int, j: int) -> Dictionary:
    if i > GRID_MAX or j > GRID_MAX:
        return {"i": i, "j": j, "kind": "none", "entries": []}
    var rng := RandomNumberGenerator.new()
    rng.seed = SEED * 100003 + (i + 64) * 1009 + (j + 64) * 31
    var center := Vector3((float(i) + 0.5) * PITCH, 0.0, (float(j) + 0.5) * PITCH)
    var dist := Vector2(center.x, center.z).length()
    var kind := "suburb"
    if dist > 60.0 and rng.randf() < PARK_CHANCE:
        kind = "park"
    elif dist < 140.0:
        kind = "downtown"
    elif dist < 260.0:
        kind = "mid"
    elif dist < 420.0 or rng.randf() < 0.5:
        kind = "suburb"
    else:
        kind = "industrial"
    var entries: Array = []
    match kind:
        "downtown":
            _plan_towers(rng, center, 8, 20, ["facade_glass", "facade_glass", "facade_concrete"], entries)
        "mid":
            _plan_towers(rng, center, 3, 8, ["facade_brick", "facade_concrete", "facade_glass"], entries)
        "suburb":
            _plan_suburb(rng, center, entries)
        "industrial":
            _plan_industrial(rng, center, entries)
        "park":
            park_count += 1
            park_rects.append(Rect2(center.x - BLOCK_SIZE * 0.5, center.z - BLOCK_SIZE * 0.5, BLOCK_SIZE, BLOCK_SIZE))
            for n in 9:
                var tx := rng.randf_range(-15.0, 15.0)
                var tz := rng.randf_range(-15.0, 15.0)
                if absf(tx) < 3.0 or absf(tz) < 3.0:
                    continue
                entries.append(_tree_entry(rng, Vector3(center.x + tx, FLAT_Y, center.z + tz), 0.9, 1.4))
    return {"i": i, "j": j, "kind": kind, "center": center, "entries": entries}


func _tree_entry(rng: RandomNumberGenerator, pos: Vector3, s_min: float, s_max: float) -> Dictionary:
    var g := rng.randf()
    return {"type": "tree", "pos": pos, "s": rng.randf_range(s_min, s_max), "leaf": Color(0.15 + 0.1 * g, 0.4 + 0.2 * g, 0.15)}


func _plan_towers(rng: RandomNumberGenerator, center: Vector3, lo: int, hi: int, styles: Array, entries: Array) -> void:
    for qx: float in [-1.0, 1.0]:
        for qz: float in [-1.0, 1.0]:
            var w := _snap4(rng.randf_range(12.0, 17.0))
            var d := _snap4(rng.randf_range(12.0, 17.0))
            var floors := rng.randi_range(lo, hi)
            var style: String = styles[rng.randi() % styles.size()]
            var tint: Color
            if style == "facade_glass":
                tint = Color.from_hsv(rng.randf_range(0.5, 0.62), rng.randf_range(0.0, 0.2), rng.randf_range(0.85, 1.0))
            else:
                tint = Color.from_hsv(rng.randf_range(0.0, 0.12), rng.randf_range(0.0, 0.15), rng.randf_range(0.8, 1.0))
            var f2 := 0
            var rw := w
            var rd := d
            if floors > 12:
                f2 = 3 + rng.randi() % 3
                rw = w - 4.0
                rd = d - 4.0
            var roof: Array = []
            for n in 1 + rng.randi() % 3:
                var bw := rng.randf_range(1.5, 3.0)
                roof.append({"x": rng.randf_range(-rw * 0.5 + 2.0, rw * 0.5 - 2.0), "z": rng.randf_range(-rd * 0.5 + 2.0, rd * 0.5 - 2.0), "w": bw, "h": rng.randf_range(1.0, 2.0)})
            var awning: Color = AWNINGS[rng.randi() % AWNINGS.size()]
            var e := {"type": "tower", "pos": center + Vector3(qx * 10.0, 0.0, qz * 10.0), "w": w, "d": d, "floors": floors, "f2": f2,
                "style": style, "tint": tint, "qz": qz, "awning": awning, "roof": roof, "rw": rw, "rd": rd}
            entries.append(e)
            _register(e)


func _plan_suburb(rng: RandomNumberGenerator, center: Vector3, entries: Array) -> void:
    for qx: float in [-1.0, 1.0]:
        for qz: float in [-1.0, 1.0]:
            var w := 12.0 if rng.randf() < 0.6 else 8.0
            var plaster: Color = PLASTERS[rng.randi() % PLASTERS.size()]
            var roof: Color = ROOFS[rng.randi() % ROOFS.size()]
            var e := {"type": "house", "pos": center + Vector3(qx * 10.0, 0.0, qz * 10.0), "w": w, "d": 8.0, "qz": qz, "plaster": plaster, "roof": roof}
            entries.append(e)
            _register(e)
            entries.append(_tree_entry(rng, Vector3(center.x + qx * rng.randf_range(3.0, 17.0), FLAT_Y, center.z + qz * rng.randf_range(1.5, 4.5)), 0.8, 1.2))
            entries.append(_tree_entry(rng, Vector3(center.x + qx * 17.5, FLAT_Y, center.z + qz * rng.randf_range(9.0, 15.0)), 0.8, 1.1))


func _plan_industrial(rng: RandomNumberGenerator, center: Vector3, entries: Array) -> void:
    var wc: Color = WAREHOUSES[rng.randi() % WAREHOUSES.size()]
    var e := {"type": "warehouse", "pos": center + Vector3(0.0, 0.0, -10.0), "w": 32.0, "d": 16.0, "h": rng.randf_range(8.0, 11.0), "color": wc}
    entries.append(e)
    _register(e)
    for cx: float in [-12.0, -4.0, 4.0, 12.0]:
        for cz: float in [6.0, 14.0]:
            if rng.randf() < 0.75:
                var col: Color = CONTAINERS[rng.randi() % CONTAINERS.size()]
                entries.append({"type": "container", "pos": center + Vector3(cx, 0.0, cz), "color": col, "stack": 1 + rng.randi() % 2})


# --------------------------------------------------------------- construção da célula

func _build_cell(i: int, j: int) -> void:
    var key := Vector2i(i, j)
    var cell := Node3D.new()
    cell.name = "Cell_%d_%d" % [i, j]
    add_child(cell)
    var sts := _new_sts()
    var body := StaticBody3D.new()
    cell.add_child(body)
    _build_roads(sts, i, j)
    var layout: Dictionary = _layouts[key]
    if layout["kind"] != "none":
        _build_block(sts, body, layout)
    _commit(sts, cell, "Mesh")
    _loaded[key] = cell


func _build_roads(sts: Dictionary, i: int, j: int) -> void:
    var ox := float(i) * PITCH
    var oz := float(j) * PITCH
    var asphalt: SurfaceTool = sts["asphalt"]
    var plain: SurfaceTool = sts["plain"]
    var yellow := Color(0.95, 0.8, 0.2)
    var white := Color(0.93, 0.93, 0.93)
    var hw := ROAD_WIDTH * 0.5
    GeoScript.flat_quad(asphalt, ox - hw, oz - hw, ox + hw, oz + hw, FLAT_Y, 6.0, Color.WHITE)
    if j < GraphScript.ROAD_MAX:
        GeoScript.flat_quad(asphalt, ox - hw, oz + hw, ox + hw, oz + PITCH - hw, FLAT_Y, 6.0, Color.WHITE)
        var z := oz + 11.0
        while z + 3.0 <= oz + PITCH - 11.0:
            GeoScript.flat_quad(plain, ox - 0.1, z, ox + 0.1, z + 3.0, MARK_Y, 1.0, yellow)
            z += 6.0
    if i < GraphScript.ROAD_MAX:
        GeoScript.flat_quad(asphalt, ox + hw, oz - hw, ox + PITCH - hw, oz + hw, FLAT_Y, 6.0, Color.WHITE)
        var x := ox + 11.0
        while x + 3.0 <= ox + PITCH - 11.0:
            GeoScript.flat_quad(plain, x, oz - 0.1, x + 3.0, oz + 0.1, MARK_Y, 1.0, yellow)
            x += 6.0
    for n in 11:
        var o := -5.0 + float(n)
        GeoScript.flat_quad(plain, ox + 7.0, oz + o - 0.25, ox + 10.0, oz + o + 0.25, MARK_Y, 1.0, white)
        GeoScript.flat_quad(plain, ox - 10.0, oz + o - 0.25, ox - 7.0, oz + o + 0.25, MARK_Y, 1.0, white)
        GeoScript.flat_quad(plain, ox + o - 0.25, oz + 7.0, ox + o + 0.25, oz + 10.0, MARK_Y, 1.0, white)
        GeoScript.flat_quad(plain, ox + o - 0.25, oz - 10.0, ox + o + 0.25, oz - 7.0, MARK_Y, 1.0, white)


func _slab(sts: Dictionary, c: Vector3) -> void:
    GeoScript.flat_quad(sts["concrete"], c.x - 20.0, c.z - 20.0, c.x + 20.0, c.z + 20.0, FLAT_Y, 3.0, Color.WHITE)


func _sidewalk_ring(sts: Dictionary, c: Vector3) -> void:
    var st: SurfaceTool = sts["concrete"]
    GeoScript.flat_quad(st, c.x - 20.0, c.z - 20.0, c.x + 20.0, c.z - 17.0, FLAT_Y, 3.0, Color.WHITE)
    GeoScript.flat_quad(st, c.x - 20.0, c.z + 17.0, c.x + 20.0, c.z + 20.0, FLAT_Y, 3.0, Color.WHITE)
    GeoScript.flat_quad(st, c.x - 20.0, c.z - 17.0, c.x - 17.0, c.z + 17.0, FLAT_Y, 3.0, Color.WHITE)
    GeoScript.flat_quad(st, c.x + 17.0, c.z - 17.0, c.x + 20.0, c.z + 17.0, FLAT_Y, 3.0, Color.WHITE)


func _build_block(sts: Dictionary, body: StaticBody3D, layout: Dictionary) -> void:
    var center: Vector3 = layout["center"]
    match layout["kind"]:
        "downtown", "mid", "industrial":
            _slab(sts, center)
        "suburb":
            _sidewalk_ring(sts, center)
        "park":
            _sidewalk_ring(sts, center)
            GeoScript.flat_quad(sts["grass"], center.x - 17.0, center.z - 17.0, center.x + 17.0, center.z + 17.0, 0.055, 6.0, Color.WHITE)
            GeoScript.flat_quad(sts["concrete"], center.x - 1.5, center.z - 17.0, center.x + 1.5, center.z + 17.0, 0.08, 3.0, Color.WHITE)
            GeoScript.flat_quad(sts["concrete"], center.x - 17.0, center.z - 1.5, center.x + 17.0, center.z + 1.5, 0.08, 3.0, Color.WHITE)
    for e: Dictionary in layout["entries"]:
        match e["type"]:
            "tower":
                _draw_tower(sts, body, e)
            "house":
                _draw_house(sts, body, e)
            "tree":
                _draw_tree(sts, body, e)
            "warehouse":
                _draw_warehouse(sts, body, e)
            "container":
                _draw_container(sts, body, e)
    _add_lamps(sts, body, center)


func _draw_tower(sts: Dictionary, body: StaticBody3D, e: Dictionary) -> void:
    var pos: Vector3 = e["pos"]
    var w: float = e["w"]
    var d: float = e["d"]
    var tint: Color = e["tint"]
    var y := FLAT_Y
    GeoScript.box(sts["storefront"], Vector3(pos.x, FLAT_Y, pos.z), Vector3(w, GROUND_FLOOR_H, d), Vector2(8.0, 4.0), FLAT_Y, Color(0.92, 0.92, 0.96), true, false, false)
    y = FLAT_Y + GROUND_FLOOR_H
    var fac: SurfaceTool = sts[e["style"]]
    var h1 := float(e["floors"]) * FLOOR_H
    GeoScript.box(fac, Vector3(pos.x, y, pos.z), Vector3(w, h1, d), FACADE_TILE, y, tint, true, false, false)
    var top := y + h1
    var rw: float = e["rw"]
    var rd: float = e["rd"]
    if int(e["f2"]) > 0:
        GeoScript.top_quad(sts["roof_gravel"], pos.x, pos.z, w, d, top, 4.0, Color.WHITE)
        GeoScript.box(fac, Vector3(pos.x, top, pos.z), Vector3(rw, float(e["f2"]) * FLOOR_H, rd), FACADE_TILE, top, tint, true, false, false)
        top += float(e["f2"]) * FLOOR_H
    GeoScript.top_quad(sts["roof_gravel"], pos.x, pos.z, rw, rd, top, 4.0, Color.WHITE)
    for item: Dictionary in e["roof"]:
        var bw: float = item["w"]
        GeoScript.box(sts["plain"], Vector3(pos.x + float(item["x"]), top, pos.z + float(item["z"])), Vector3(bw, float(item["h"]), bw), Vector2.ONE, 0.0, Color(0.6, 0.6, 0.62), true, true, false)
    GeoScript.box(sts["plain"], Vector3(pos.x, FLAT_Y + 3.2, pos.z + float(e["qz"]) * (d * 0.5 + 0.6)), Vector3(w * 0.6, 0.12, 1.2), Vector2.ONE, 0.0, e["awning"], true, true, true)
    _collider(body, Vector3(pos.x, top * 0.5, pos.z), Vector3(w, top, d))


func _draw_house(sts: Dictionary, body: StaticBody3D, e: Dictionary) -> void:
    var pos: Vector3 = e["pos"]
    var w: float = e["w"]
    var d: float = e["d"]
    var plaster: Color = e["plaster"]
    var roof_color: Color = e["roof"]
    var wall_h := 6.0
    var rh := 2.6
    var ov := 0.5
    GeoScript.box(sts["house_wall"], Vector3(pos.x, FLAT_Y, pos.z), Vector3(w, wall_h, d), Vector2(8.0, 6.0), FLAT_Y, plaster, true, false, false)
    var x0 := pos.x - w * 0.5 - ov
    var x1 := pos.x + w * 0.5 + ov
    var zf := pos.z + d * 0.5 + ov
    var zb := pos.z - d * 0.5 - ov
    var eave := FLAT_Y + wall_h - 0.15
    var ridge := FLAT_Y + wall_h + rh
    var roof: SurfaceTool = sts["roof_tile"]
    GeoScript.quad(roof, Vector3(x0, eave, zf), Vector3(x1, eave, zf), Vector3(x1, ridge, pos.z), Vector3(x0, ridge, pos.z), Vector3(0, 1, 0.8), roof_color,
        Vector2(x0, zf) / 3.0, Vector2(x1, zf) / 3.0, Vector2(x1, pos.z) / 3.0, Vector2(x0, pos.z) / 3.0)
    GeoScript.quad(roof, Vector3(x1, eave, zb), Vector3(x0, eave, zb), Vector3(x0, ridge, pos.z), Vector3(x1, ridge, pos.z), Vector3(0, 1, -0.8), roof_color,
        Vector2(x1, zb) / 3.0, Vector2(x0, zb) / 3.0, Vector2(x0, pos.z) / 3.0, Vector2(x1, pos.z) / 3.0)
    for sx: float in [-1.0, 1.0]:
        var xr := pos.x + sx * w * 0.5
        GeoScript.tri(sts["plain"], Vector3(xr, FLAT_Y + wall_h, pos.z - d * 0.5), Vector3(xr, FLAT_Y + wall_h, pos.z + d * 0.5), Vector3(xr, ridge, pos.z), Vector3(sx, 0, 0), plaster)
    GeoScript.box(sts["plain"], Vector3(pos.x + w * 0.25, FLAT_Y + wall_h + 0.4, pos.z + 0.6), Vector3(0.9, 2.6, 0.9), Vector2.ONE, 0.0, Color(0.55, 0.3, 0.25), true, true, false)
    var z_a := pos.z + float(e["qz"]) * (d * 0.5)
    var z_b := pos.z + float(e["qz"]) * (d * 0.5 + 3.0)
    GeoScript.flat_quad(sts["concrete"], pos.x - 1.5, minf(z_a, z_b), pos.x + 1.5, maxf(z_a, z_b), FLAT_Y + 0.01, 3.0, Color.WHITE)
    _collider(body, Vector3(pos.x, FLAT_Y + (wall_h + rh * 0.7) * 0.5, pos.z), Vector3(w, wall_h + rh * 0.7, d))


func _draw_tree(sts: Dictionary, body: StaticBody3D, e: Dictionary) -> void:
    var p: Vector3 = e["pos"]
    var s: float = e["s"]
    var leaf: Color = e["leaf"]
    var plain: SurfaceTool = sts["plain"]
    GeoScript.box(plain, p, Vector3(0.35 * s, 2.2 * s, 0.35 * s), Vector2.ONE, 0.0, Color(0.35, 0.22, 0.12), true, true, false)
    GeoScript.cone(plain, p + Vector3(0.0, 1.5 * s, 0.0), 1.8 * s, 3.2 * s, 8, leaf)
    GeoScript.cone(plain, p + Vector3(0.0, 3.2 * s, 0.0), 1.3 * s, 2.6 * s, 8, leaf.lightened(0.08))
    _collider(body, p + Vector3(0.0, 1.5 * s, 0.0), Vector3(0.6 * s, 3.0 * s, 0.6 * s))


func _draw_warehouse(sts: Dictionary, body: StaticBody3D, e: Dictionary) -> void:
    var pos: Vector3 = e["pos"]
    var w: float = e["w"]
    var d: float = e["d"]
    var h: float = e["h"]
    var color: Color = e["color"]
    var plain: SurfaceTool = sts["plain"]
    GeoScript.box(plain, Vector3(pos.x, FLAT_Y, pos.z), Vector3(w, h, d), Vector2.ONE, 0.0, color, true, true, false)
    GeoScript.box(plain, Vector3(pos.x, FLAT_Y + h, pos.z), Vector3(w + 0.4, 0.3, d + 0.4), Vector2.ONE, 0.0, color.darkened(0.25), true, true, false)
    for dx: float in [-8.0, 0.0, 8.0]:
        GeoScript.box(plain, Vector3(pos.x + dx, FLAT_Y, pos.z + d * 0.5 + 0.05), Vector3(6.0, 5.0, 0.15), Vector2.ONE, 0.0, Color(0.25, 0.27, 0.3), true, true, false)
    _collider(body, Vector3(pos.x, FLAT_Y + h * 0.5, pos.z), Vector3(w, h, d))


func _draw_container(sts: Dictionary, body: StaticBody3D, e: Dictionary) -> void:
    var pos: Vector3 = e["pos"]
    var stack: int = e["stack"]
    var color: Color = e["color"]
    for n in stack:
        GeoScript.box(sts["plain"], Vector3(pos.x, FLAT_Y + float(n) * 2.4, pos.z), Vector3(6.0, 2.4, 2.4), Vector2.ONE, 0.0, color, true, true, false)
    _collider(body, Vector3(pos.x, FLAT_Y + float(stack) * 1.2, pos.z), Vector3(6.0, float(stack) * 2.4, 2.4))


func _add_lamps(sts: Dictionary, body: StaticBody3D, c: Vector3) -> void:
    var plain: SurfaceTool = sts["plain"]
    for p: Vector2 in [Vector2(0.0, -21.5), Vector2(0.0, 21.5), Vector2(-21.5, 0.0), Vector2(21.5, 0.0)]:
        var base := Vector3(c.x + p.x, FLAT_Y, c.z + p.y)
        var dir := p.normalized()
        GeoScript.box(plain, base, Vector3(0.14, 5.5, 0.14), Vector2.ONE, 0.0, Color(0.2, 0.2, 0.22), true, true, false)
        GeoScript.box(plain, base + Vector3(dir.x * 0.5, 5.4, dir.y * 0.5), Vector3(absf(dir.x) + 0.1, 0.1, absf(dir.y) + 0.1), Vector2.ONE, 0.0, Color(0.2, 0.2, 0.22), true, true, true)
        GeoScript.box(plain, base + Vector3(dir.x * 1.0, 5.3, dir.y * 1.0), Vector3(0.4, 0.1, 0.4), Vector2.ONE, 0.0, Color(1.0, 0.95, 0.8), true, true, true)
        _collider(body, base + Vector3(0.0, 2.75, 0.0), Vector3(0.25, 5.5, 0.25))


# ------------------------------------------------------------- objetos de teste

func _add_test_props() -> void:
    # Rampa na avenida à frente do ponto de partida (o jogador começa olhando para -Z).
    var ramp := _add_box(Vector3(6.0, 0.4, 10.0), Vector3(0.0, 1.45, -22.0), Color(0.7, 0.5, 0.2), true)
    ramp.rotation_degrees.x = 15.0
    # Caixas para testar pulo e colisão.
    _add_box(Vector3(1.0, 1.0, 1.0), Vector3(4.0, 0.5, -8.0), Color(0.6, 0.4, 0.2), true)
    _add_box(Vector3(1.0, 1.0, 1.0), Vector3(-4.0, 0.5, -8.0), Color(0.6, 0.4, 0.2), true)
    _add_box(Vector3(2.0, 2.0, 2.0), Vector3(-4.0, 1.0, -12.0), Color(0.5, 0.35, 0.2), true)
    _add_box(Vector3(0.5, 1.2, 6.0), Vector3(3.0, 0.6, 8.0), Color(0.5, 0.5, 0.55), true)


func _material(color: Color) -> StandardMaterial3D:
    var key := color.to_html()
    if not _materials.has(key):
        var mat := StandardMaterial3D.new()
        mat.albedo_color = color
        mat.roughness = 0.9
        _materials[key] = mat
    return _materials[key]


func _add_box(size: Vector3, pos: Vector3, color: Color, collide: bool) -> Node3D:
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh.mesh = box
    mesh.material_override = _material(color)
    if not collide:
        mesh.position = pos
        add_child(mesh)
        return mesh

    var body := StaticBody3D.new()
    body.position = pos
    var shape := CollisionShape3D.new()
    var box_shape := BoxShape3D.new()
    box_shape.size = size
    shape.shape = box_shape
    body.add_child(shape)
    body.add_child(mesh)
    add_child(body)
    return body
