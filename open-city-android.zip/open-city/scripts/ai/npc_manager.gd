extends Node
## Cria e recicla pedestres, carros do trânsito e carros ESTACIONADOS ao redor do jogador.
## Pedestres e trânsito longe demais são reposicionados perto (sem criar/destruir nós).
## Os carros estacionados ficam em "vagas" fixas e determinísticas ao longo das ruas
## (as mais próximas do jogador, conforme a quantidade das configurações).

const PedScript := preload("res://scripts/ai/pedestrian.gd")
const TrafficScript := preload("res://scripts/ai/traffic_car.gd")
const GraphScript := preload("res://scripts/ai/city_graph.gd")
const DataScript := preload("res://scripts/vehicles/vehicle_data.gd")

const DESPAWN_DISTANCE := 170.0
const SPAWN_MIN := 25.0
const SPAWN_MAX := 140.0
const MAX_NEW_PER_TICK := 3
const ABANDONED_DISTANCE := 200.0
const PARKED_RADIUS_CELLS := 3

var player: Node3D

var _peds: Array = []
var _cars: Array = []
var _parked := {} # Vector3i (vaga) -> carro
var _taken := {} # vagas cujo carro o jogador pegou
var _timer := 0.0
var _first := true
var _age := 0.0


func _physics_process(delta: float) -> void:
    _age += delta
    _timer -= delta
    if _timer > 0.0:
        return
    _timer = 0.15 if _age < 8.0 else 0.5
    if player == null or not is_instance_valid(player):
        return
    _peds = _peds.filter(func(n: Variant) -> bool: return is_instance_valid(n))
    _cars = _cars.filter(func(n: Variant) -> bool: return is_instance_valid(n))

    var budget := 6 if _age < 8.0 else MAX_NEW_PER_TICK
    var rmin := 10.0 if _first else SPAWN_MIN
    if _first:
        _spawn_nearby_peds(3)
    budget = _sync_peds(GameSettings.ped_count, budget, rmin)
    budget = _sync_cars(GameSettings.traffic_count, budget, rmin)
    _sync_parked(4 if _age < 8.0 else 2)
    _first = false
    _recycle()
    _cleanup_abandoned()


## Alguns pedestres já à vista quando o jogo começa.
func _spawn_nearby_peds(count: int) -> void:
    var nodes := GraphScript.ped_nodes_in_range(player.global_position, 10.0, 60.0)
    for i in count:
        if nodes.is_empty():
            return
        var ped = PedScript.new()
        ped.place(nodes.pick_random())
        add_child(ped)
        _peds.append(ped)


func _sync_peds(target_count: int, budget: int, rmin: float) -> int:
    while _peds.size() < target_count and budget > 0:
        var nodes := GraphScript.ped_nodes_in_range(player.global_position, rmin, SPAWN_MAX)
        if nodes.is_empty():
            break
        var ped = PedScript.new()
        ped.place(nodes.pick_random())
        add_child(ped)
        _peds.append(ped)
        budget -= 1
    while _peds.size() > target_count:
        var extra = _peds.pop_back()
        extra.queue_free()
    return budget


func _sync_cars(target_count: int, budget: int, rmin: float) -> int:
    while _cars.size() < target_count and budget > 0:
        var car = _make_car(rmin)
        if car == null:
            break
        add_child(car)
        _cars.append(car)
        budget -= 1
    while _cars.size() > target_count:
        var extra = _cars.pop_back()
        extra.queue_free()
    return budget


func _random_type() -> String:
    return DataScript.TRAFFIC_MIX.pick_random()


func _make_car(rmin: float) -> Node:
    var starts := GraphScript.traffic_starts_in_range(player.global_position, rmin, SPAWN_MAX)
    if starts.is_empty():
        return null
    var id := _random_type()
    var colors: Array = DataScript.TYPES[id]["colors"]
    var color: Color = colors.pick_random()
    var car = TrafficScript.new()
    car.setup(id, color)
    for attempt in 6:
        var s: Dictionary = starts.pick_random()
        car.start(s["ix"], s["iz"], s["dir"])
        if _is_free_spot(car.position):
            return car
    car.free()
    return null


func _is_free_spot(pos: Vector3) -> bool:
    if Vector2(pos.x - player.global_position.x, pos.z - player.global_position.z).length() < 20.0:
        return false
    for other in _cars:
        if is_instance_valid(other) and other.position.distance_to(pos) < 10.0:
            return false
    return true


# ---------------------------------------------------------------- estacionados

## Vaga k (0..11) do cruzamento (i, j): 2 eixos x 2 lados x 3 posições. Determinística.
func _slot(i: int, j: int, k: int) -> Dictionary:
    var axis := k / 6
    if (axis == 0 and i >= GraphScript.ROAD_MAX) or (axis == 1 and j >= GraphScript.ROAD_MAX):
        return {}
    var h := absi(hash(Vector3i(i, j, k)))
    if h % 100 >= 50:
        return {}
    var side := (k / 3) % 2
    var idx := k % 3
    var ox := float(i) * GraphScript.PITCH
    var oz := float(j) * GraphScript.PITCH
    var pos: Vector3
    var dir: Vector2i
    if axis == 0:
        pos = Vector3(ox + 16.0 + float(idx) * 11.0, 0.9, oz + (4.8 if side == 0 else -4.8))
        dir = Vector2i(1, 0) if side == 0 else Vector2i(-1, 0)
    else:
        pos = Vector3(ox + (-4.8 if side == 0 else 4.8), 0.9, oz + 16.0 + float(idx) * 11.0)
        dir = Vector2i(0, 1) if side == 0 else Vector2i(0, -1)
    var mix: Array = DataScript.TRAFFIC_MIX
    var id: String = mix[(h / 100) % mix.size()]
    var colors: Array = DataScript.TYPES[id]["colors"]
    var color: Color = colors[(h / 7919) % colors.size()]
    return {"key": Vector3i(i, j, k), "pos": pos, "yaw": atan2(-float(dir.x), -float(dir.y)), "type": id, "color": color}


func _sync_parked(budget: int) -> void:
    for key in _parked.keys():
        if not is_instance_valid(_parked[key]):
            _taken[key] = true
            _parked.erase(key)
    if _taken.size() > 300:
        _taken.clear()

    var want: int = GameSettings.parked_count
    var center := player.global_position
    var ci := floori(center.x / GraphScript.PITCH)
    var cj := floori(center.z / GraphScript.PITCH)
    var slots: Array = []
    for i in range(ci - PARKED_RADIUS_CELLS, ci + PARKED_RADIUS_CELLS + 1):
        for j in range(cj - PARKED_RADIUS_CELLS, cj + PARKED_RADIUS_CELLS + 1):
            if i < GraphScript.ROAD_MIN or i > GraphScript.ROAD_MAX or j < GraphScript.ROAD_MIN or j > GraphScript.ROAD_MAX:
                continue
            for k in 12:
                var s := _slot(i, j, k)
                if s.is_empty() or _taken.has(s["key"]):
                    continue
                var p: Vector3 = s["pos"]
                s["d"] = Vector2(p.x - center.x, p.z - center.z).length()
                slots.append(s)
    slots.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return a["d"] < b["d"])
    var desired := {}
    var limit := 0.0
    for n in mini(want, slots.size()):
        desired[slots[n]["key"]] = slots[n]
        limit = slots[n]["d"]
    for key in _parked.keys():
        if desired.has(key):
            continue
        var node: Node3D = _parked[key]
        if Vector2(node.position.x - center.x, node.position.z - center.z).length() > limit + 20.0:
            node.queue_free()
            _parked.erase(key)
    for key in desired:
        if budget <= 0:
            return
        if _parked.has(key):
            continue
        var s: Dictionary = desired[key]
        if _spot_blocked(s["pos"]):
            continue
        var car = TrafficScript.new()
        car.setup(s["type"], s["color"])
        car.parked = true
        car.position = s["pos"]
        car.rotation.y = s["yaw"]
        add_child(car)
        _parked[key] = car
        budget -= 1


func _spot_blocked(pos: Vector3) -> bool:
    for v in get_tree().get_nodes_in_group("vehicles"):
        if v.global_position.distance_to(pos) < 5.0:
            return true
    return false


func _recycle() -> void:
    var center := player.global_position
    for ped in _peds:
        if Vector2(ped.global_position.x - center.x, ped.global_position.z - center.z).length() > DESPAWN_DISTANCE:
            var nodes := GraphScript.ped_nodes_in_range(center, SPAWN_MIN, SPAWN_MAX)
            if not nodes.is_empty():
                ped.place(nodes.pick_random())
    for car in _cars:
        if Vector2(car.global_position.x - center.x, car.global_position.z - center.z).length() > DESPAWN_DISTANCE:
            var starts := GraphScript.traffic_starts_in_range(center, SPAWN_MIN, SPAWN_MAX)
            if not starts.is_empty():
                var s: Dictionary = starts.pick_random()
                car.start(s["ix"], s["iz"], s["dir"])


## Carros do trânsito que o jogador pegou e largou longe são removidos.
func _cleanup_abandoned() -> void:
    var center := player.global_position
    for v in get_tree().get_nodes_in_group("vehicles"):
        if v.recyclable and v.driver == null:
            if Vector2(v.global_position.x - center.x, v.global_position.z - center.z).length() > ABANDONED_DISTANCE:
                v.queue_free()
